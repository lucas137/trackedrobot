// Constants used in program


#define safedistance   150    // Objects closer than this will trigger object avoidance
#define maxdistance    100    // Maximum distance before an object is considered "out of range"
#define bestdistance   500    // Best distance to be from object so tracking won't be lost if object moves suddenly

#define pancenter     1500    // Center position of pan servo in uS
#define panmin         700    // Pan servo lower limit in uS
#define panmax        2300    // Pan servo upper limit in uS
#define panscalefact     4    // Scale factor to prevent pan servo overcorrecting

#define tiltcenter    1500    // Center position of tilt servo in uS
#define tiltmin        700    // Tilt servo lower limit in uS
#define tiltmax       1800    // Tilt servo upper limit in uS
#define tiltscalefact    4    // Scale factor to prevent tilt servo overcorrecting

#define explorespeed   150    // travel speed when robot is exploring
#define activetrack      3    // panadjust or tiltadjust must exceed this value to be actively tracking a moving object
#define patience      4000    // milliseconds without stimulation in playmode required to become bored
#define reversetime   2000    // time to reverse in milliseconds



// deadband values prevent the robot over reacting to small movements of the object

#define disdeadband     40    // Distance deadband allows the object to change distance a small amount without robot reacting
#define pandeadband    300    // Pan deadband allows head to pan a small amount before body begins tracking object in uS   


