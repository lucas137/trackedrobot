// Rover 5 Explorer with Arduino Mega or DAGU Spider
// This page tells the controller which pin is connected to which sensor, switch, motor etc.
// You can re-define the pins here to suit your robot. This is your wiring diagram!
// Pins are usually chosen by their function but in some cases by physical location (shorter wires).
// You may not require all functions listed here, ignore those you do not need.

#define CELpin   8       // Compound Eye Left      - analog   input        A8 
#define CERpin   9       // Compound Eye Right     - analog   input        A9     
#define CEUpin  10       // Compound Eye Up        - analog   input       A10 
#define CEDpin  11       // Compound Eye Down      - analog   input       A11 
#define CEIpin  53       // Compound Eye LEDs      - digital  output      D53 

#define PANpin  15       // PAN   left  or  right  - digital  output      D15
#define TILpin  14       // TILt  up    and  down  - digital  output      D14

#define LMDpin   6       // Left  Motor Direction  - digital  output       D6
#define LMSpin   7       // Left  Motor Speed PWM  - digital  output       D7
#define LMCpin   6       // Left  Motor Current    - analog   input        A6
#define LMApin   2       // Left  Motor Encoder A  - external Interrupt0   D2
#define LMBpin   3       // Left  Motor Encoder B  - external Interrupt1   D3

#define RMSpin   5       // Right Motor Speed PWM  - digital  output       D5
#define RMDpin   4       // Right Motor Direction  - digital  output       D4
#define RMCpin   7       // Right Motor Current    - analog   input        A7
#define RMApin  18       // Right Motor Encoder A  - external interrupt5  D18
#define RMBpin  19       // Right Motor Encoder B  - external interrupt4  D19
 
#define FRSpin  12       // Front Right Sensor     - analog   input       A12
#define FLSpin  13       // Front Left  Sensor     - analog   input       A13
#define RLSpin  14       // Rear  Left  Sensor     - analog   input       A14
#define RRSpin  15       // Rear  Right Sensor     - analog   input       A15

#define FRLpin   8       // Front Right  LEDs      - digital  output       D8
#define FLLpin   9       // Front Left   LEDs      - digital  output       D9
#define RLLpin  10       // Rear  Left   LEDs      - digital  output      D10
#define RRLpin  11       // Rear  Right  LEDs      - digital  output      D11


// Note: optional speaker should have a series capacitor of between 10uF and 100uF

#define Speaker 13       // Speaker                - digital  output      D13   








